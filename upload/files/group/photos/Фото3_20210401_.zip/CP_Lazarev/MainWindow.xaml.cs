﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CP_Lazarev
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<ProgramClass> allProgramms;

        /*
         * ОБЩИЕ НЕЧЕТКИЕ ОЦЕНКИ
         * 0 - очень плохо
         * 1 - плохо
         * 2 - нормально
         * 3 - хорошо
         * 4 - очень хорошо
         */

        /*
         * ЦЕНОВОЙ СЕГМЕНТ (цена лицензии)
         * 0 - 100 000 и дороже (очень дорого)
         * 1 - 70 000 - 120 000 (дорого)
         * 2 - 50 000 - 80 000 (умеренно)
         * 3 - 30 000 - 60 000 (дешево)
         * 4 - 40 000 и дешевле (очень дешево)
         */
        /*
        * ЦЕНОВОЙ СЕГМЕНТ (длительность)
        * 0 - больше 12 месяцев (очень долго)
        * 1 - от 6 до 14 месяцев (долго)
        * 2 - от 4 до 8 месяцев (средний срок)
        * 3 - от 2 до 5 месяцев (малый срок)
        * 4 - менее 3 месяцев (очень малый срок)
        */
        public List<List<int>> fuzzyTablePrice;

        /*
         * СЕГМЕНТ ИСПОЛЬЗОВАНИЯ ПО (количество запусков)
         * 0 - более 100 (очень много)
         * 1 - от 70 до 110 (много)
         * 2 - от 50 до 80 (средне)
         * 3 - от 30 до 60 (мало)
         * 4 - менее 40 (очень мало)
         */
        /*
        * СЕГМЕНТ ИСПОЛЬЗОВАНИЯ ПО (среднее время одного сеанса в минутах)
        * 0 - более 60 (очень долго)
        * 1 - от 50 до 70 (долго)
        * 2 - от 30 до 60 (средне)
        * 3 - от 10 до 40 (мало)
        * 4 - менее 20 (очень мало)
        */
        public List<List<int>> fuzzyTableUse;
        public MainWindow()
        {
            InitializeComponent();
            fuzzyTablePrice = new List<List<int>>
            {
                new List<int>() {3, 3, 4, 4, 4},
                new List<int>() {2, 3, 3, 4, 4},
                new List<int>() {2, 2, 3, 3, 4},
                new List<int>() {1, 1, 2, 2, 3},
                new List<int>() {0, 1, 1, 2, 3},
            };
            fuzzyTableUse = new List<List<int>>
            {
                new List<int>() {4, 4, 3, 3, 2},
                new List<int>() {4, 3, 3, 2, 2},
                new List<int>() {3, 3, 2, 2, 1},
                new List<int>() {3, 2, 2, 1, 1},
                new List<int>() {2, 2, 1, 1, 0},
            };
            RefreshList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PO form = new PO();
            form.Show();
        }

        public void RefreshListWithoutFile()
        {
            list.Items.Clear();
            for (int i = 0; i != allProgramms.Count; ++i)
                list.Items.Add(allProgramms[i].nameP);
        }
        public void RefreshList()
        {
            List<string> allData = new List<string>();
            allProgramms = new List<ProgramClass>();
            StreamReader sr = new StreamReader("po.txt");
            while (!sr.EndOfStream)
                allData.Add(sr.ReadLine());
            sr.Close();

            for (int i = 0; i != allData.Count; ++i)
                allProgramms.Add(new ProgramClass(allData[i]));

            list.Items.Clear();
            for (int i = 0; i != allProgramms.Count; ++i)
                list.Items.Add(allProgramms[i].nameP);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            RefreshList();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (list.SelectedIndex == -1)
            {
                MessageBox.Show("Не выбран элемент", "Ошибка");
            }
            else
            {
                List<string> allData = new List<string>();
                StreamReader sr = new StreamReader("po.txt");
                while (!sr.EndOfStream)
                {
                    string temp = sr.ReadLine();
                    if (temp.Split(' ').ElementAt(0) != list.SelectedItem.ToString())
                        allData.Add(temp);
                }
                sr.Close();
                StreamWriter sw = new StreamWriter("po.txt", false);
                for (int i = 0; i != allData.Count; ++i)
                    sw.WriteLine(allData[i]);
                sw.Close();
                RefreshList();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            List<int> sortIndex = new List<int>();
            for (int i = 0; i != allProgramms.Count; ++i)
            {
                int currentMinIndex = -1;
                double currentMin = 10;
                for (int c = 0; c != 5; ++c)
                    if (allProgramms[i].ConvertPriceToIndex(c) != 0 && allProgramms[i].ConvertPriceToIndex(c) < currentMin)
                    {
                        currentMin = allProgramms[i].ConvertPriceToIndex(c);
                        currentMinIndex = c;
                    }
                int currentMinIndex2 = -1;
                double currentMin2 = 10;
                for (int c = 0; c != 5; ++c)
                    if (allProgramms[i].ConvertProlongToIndex(c) != 0 && allProgramms[i].ConvertProlongToIndex(c) < currentMin2)
                    {
                        currentMin2 = allProgramms[i].ConvertProlongToIndex(c);
                        currentMinIndex2 = c;
                    }
                sortIndex.Add(fuzzyTablePrice[currentMinIndex2][currentMinIndex]);
            }

            int temp;
            ProgramClass temp2;
            for (int i = 0; i != sortIndex.Count; ++i)
            {
                for (int j = i + 1; j < sortIndex.Count; ++j)
                {
                    if (sortIndex[i] < sortIndex[j])
                    {
                        temp = sortIndex[i];
                        sortIndex[i] = sortIndex[j];
                        sortIndex[j] = temp;

                        temp2 = allProgramms[i];
                        allProgramms[i] = allProgramms[j];
                        allProgramms[j] = temp2;
                    }
                }
            }
            RefreshListWithoutFile();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            List<int> sortIndex = new List<int>();
            for (int i = 0; i != allProgramms.Count; ++i)
            {
                int currentMinIndex = -1;
                double currentMin = 10;
                for (int c = 0; c != 5; ++c)
                    if (allProgramms[i].ConvertCountToIndex(c) != 0 && allProgramms[i].ConvertCountToIndex(c) < currentMin)
                    {
                        currentMin = allProgramms[i].ConvertCountToIndex(c);
                        currentMinIndex = c;
                    }
                int currentMinIndex2 = -1;
                double currentMin2 = 10;
                for (int c = 0; c != 5; ++c)
                    if (allProgramms[i].ConvertTimeToIndex(c) != 0 && allProgramms[i].ConvertTimeToIndex(c) < currentMin2)
                    {
                        currentMin2 = allProgramms[i].ConvertTimeToIndex(c);
                        currentMinIndex2 = c;
                    }
                sortIndex.Add(fuzzyTableUse[currentMinIndex2][currentMinIndex]);
            }

            int temp;
            ProgramClass temp2;
            for (int i = 0; i != sortIndex.Count; ++i)
            {
                for (int j = i + 1; j < sortIndex.Count; ++j)
                {
                    if (sortIndex[i] < sortIndex[j])
                    {
                        temp = sortIndex[i];
                        sortIndex[i] = sortIndex[j];
                        sortIndex[j] = temp;

                        temp2 = allProgramms[i];
                        allProgramms[i] = allProgramms[j];
                        allProgramms[j] = temp2;
                    }
                }
            }
            RefreshListWithoutFile();
        }
    }

    public class ProgramClass
    {
        public string nameP;
        public int priceP;
        public int prolongP;
        public int countP;
        public int timeP;

        public ProgramClass(string str)
        {
            List<string> splitStr = str.Split(' ').ToList();
            nameP = splitStr[0];
            priceP = int.Parse(splitStr[1]);
            prolongP = int.Parse(splitStr[2]);
            countP = int.Parse(splitStr[3]);
            timeP = int.Parse(splitStr[4]);
        }

        private int CoinFlip()
        {
            Random rnd = new Random();
            return rnd.Next(0, 2);
        }

        //функции принадлежности к нечеткому множеству
        public double ConvertPriceToIndex(int index)
        {
            int rnd = CoinFlip();
            if (index == 0)
            {
                if (priceP > 100000)
                    if (priceP > 120000) return 1;
                    else return 0.5 + (rnd * 1.0 / 2.0);
                else return 0;                
            }
            else if (index == 1)
            {
                if (priceP > 70000 && priceP <= 100000) return 1;
                if (priceP > 100000 && priceP <= 120000) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 2)
            {
                if (priceP > 50000 && priceP <= 70000) return 1;
                if (priceP > 70000 && priceP <= 80000) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 3)
            {
                if (priceP > 30000 && priceP <= 50000) return 1;
                if (priceP > 50000 && priceP <= 60000) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 4)
            {
                if (priceP <= 30000) return 1;
                if (priceP > 30000 && priceP <= 40000) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            return 0;
        }

        public double ConvertProlongToIndex(int index)
        {
            int rnd = CoinFlip();
            if (index == 0)
            {
                if (prolongP > 12)
                    if (prolongP > 14) return 1;
                    else return 0.5 + (rnd * 1.0 / 2.0);
                else return 0;
            }
            else if (index == 1)
            {
                if (prolongP > 6 && prolongP <= 12) return 1;
                if (prolongP > 12 && prolongP <= 14) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 2)
            {
                if (prolongP > 4 && prolongP <= 6) return 1;
                if (prolongP > 6 && prolongP <= 8) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 3)
            {
                if (prolongP > 2 && prolongP <= 4) return 1;
                if (prolongP > 4 && prolongP <= 5) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 4)
            {
                if (prolongP <= 2) return 1;
                if (prolongP > 2 && prolongP <= 3) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            return 0;
            
        }

        public double ConvertCountToIndex(int index)
        {
            int rnd = CoinFlip();
            if (index == 0)
            {
                if (countP > 100)
                    if (countP > 110) return 1;
                    else return 0.5 + (rnd * 1.0 / 2.0);
                else return 0;
            }
            else if (index == 1)
            {
                if (countP > 70 && countP <= 100) return 1;
                if (countP > 100 && countP <= 110) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 2)
            {
                if (countP > 50 && countP <= 70) return 1;
                if (countP > 70 && countP <= 80) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 3)
            {
                if (countP > 30 && countP <= 50) return 1;
                if (countP > 50 && countP <= 60) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 4)
            {
                if (countP <= 30) return 1;
                if (countP > 30 && countP <= 40) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            return 0;
        }

        public double ConvertTimeToIndex(int index)
        {
            int rnd = CoinFlip();
            if (index == 0)
            {
                if (timeP > 60)
                    if (timeP > 70) return 1;
                    else return 0.5 + (rnd * 1.0 / 2.0);
                else return 0;
            }
            else if (index == 1)
            {
                if (timeP > 50 && timeP <= 60) return 1;
                if (timeP > 60 && timeP <= 70) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 2)
            {
                if (timeP > 30 && timeP <= 50) return 1;
                if (timeP > 50 && timeP <= 60) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 3)
            {
                if (timeP > 10 && timeP <= 30) return 1;
                if (timeP > 30 && timeP <= 40) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            else if (index == 4)
            {
                if (timeP <= 10) return 1;
                if (timeP > 10 && timeP <= 20) return 0.5 + (rnd * 1.0 / 2.0);
                return 0;
            }
            return 0;
        }
    }
}
