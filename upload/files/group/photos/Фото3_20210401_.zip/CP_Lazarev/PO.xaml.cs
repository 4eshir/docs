﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CP_Lazarev
{
    /// <summary>
    /// Логика взаимодействия для PO.xaml
    /// </summary>
    public partial class PO : Window
    {
        public PO()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (name.Text == "" || prolong.Text == "" || count.Text == "" || time.Text == "" || price.Text == "")
            {
                MessageBox.Show("Заполните все поля!", "Ошибка");
            }
            else
            {
                StreamWriter sw = new StreamWriter("po.txt", true);
                sw.WriteLine(name.Text + " " + price.Text + " " + prolong.Text + " " + count.Text + " " + time.Text);
                sw.Close();
                this.Close();
            }
        }
    }
}
